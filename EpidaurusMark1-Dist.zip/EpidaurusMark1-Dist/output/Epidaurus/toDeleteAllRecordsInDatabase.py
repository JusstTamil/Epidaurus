from sqlite3 import *

con = connect('patientHistory.db')
cur = con.cursor()
cur.execute('DELETE FROM patientHistory')
con.commit()
con.close()